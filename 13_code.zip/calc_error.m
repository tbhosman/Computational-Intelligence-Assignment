function error = calc_error( y_desired, y_actual)
% CalcError berekend de error
%   y_desired is de gewenste output binair
%   y_actual is de gekregen output binair   
    error = y_desired - y_actual;

end

