function ans = stap(in,thres)

if in < thres
    ans = 0;
else
    ans = 1;
end
end